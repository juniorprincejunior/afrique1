<?php 
/* 

CECI EST UN PETIT SCRIPT PHP DÉMONTRANT L'ENVOI PAR E-MAIL DES INFORMATIONS SOUMISES PAR UN VISITEUR  VIA UN FORMULAIRE.

N.B : Pour que ce script marche il faudrait au préalable
		- Installer un serveur SMTP destiné à l'envoi des e-mails en local
		- Paramétrer la sécurité de votre compte e-mail (gmail par exemple) pour donner l'accès à ce 	script d'utiliser votre e-mail
		- Et quelques connaissance en PHP pour bien comprendre le script

*/
$message = ''; //Variable pour l'affiche des messages aux visiteurs en fonction de ses actions

if (isset($_POST['register'])) 
{
	# code...
	/* 
		Filtrage des informations saisies par le visiteur pour une bonne sécurité 
	*/
	$username = trim(htmlspecialchars($_POST['username']));
	$usermail = trim(htmlspecialchars($_POST['usermail']));
	$userwh = trim(htmlspecialchars($_POST['userwh']));

	if (!empty($usermail) AND !empty($usermail) AND !empty($userwh)) //Verification que tous les champs on bien été rempli par le visiteur
	{
		# code...
		if (filter_var($usermail, FILTER_VALIDATE_EMAIL)) // Filtrage et verification de l'existance l'e-mail saisie par le visiteur
		{
			# code...
			/*
				Paramètre de l'entête de l'e-mail
			*/
			$header = 'MIME-Version: 1.0' . "\r\n";
          	$header .= 'From: Mon site web' . '\r\n';;
          	$header .= 'Content-type: text/html; charset=UTF-8'. "\r\n";
          	$header .= 'Content-Transfert-Encoding : 8bit';

          	$email = 'cmdkinshasa@gmail.com'; //La variable contenant l'e-mail dont il faut envoyé le message
          	$message = "
          	<html>
            	<head>
              		<meta charset='utf-8'>
              		<title></title>
            	</head>
            	<body>
              		<div class='align-center'>
                		<h1>Nouvelle inscription</h1>
                		<ul>
							<li>Nom : '$username'</li>
							<li>Adresse email : '$usermail'</li>
							<li>Numéro whatsapp : '$userwh'</li>
						</ul>
              		</div>
            	</body>
          </html>"; //La variable contenant le message à envoyer
          $destinataire = $email; //L'e-mail du destinataire dans notre cas c'est $email
          $objet = 'Nouvelle inscription'; //L'objet

          if (mail($destinataire, $objet, $message, $header)) //La fonction d'envoi d'un e-mail vérifiée pour se rassurer bel et bien si l'e-mail a été envoyé
          {
          	# code...
          	$message .= "<label class='text-danger'>Inscription réussie avec succès !</label>";
          } 
          else 
          {
          	# code...
          	$message .= "<label class='text-danger'>Une erreur est survenue lors de l'execution de votre inscription</label>";
          }
          
		} 
		else 
		{
			# code...
			$message .= "<label class='text-danger'>Votre Adresse e-mail est incorrect</label>";
		}
		
	} 
	else 
	{
		# code...
		$message .= "<label class='text-danger'>Veillez remplir tous les champs svp !</label>";

	}
	
}


 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Du formulaire à l'email</title>
	<link rel="stylesheet" type="text/css" href="dist/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-6" style="margin: 100px auto;">
				<h1 class="text-primary">Inscription</h1>
				<hr>
				<p>
				<?php 
					if (isset($message)) //Vérification du contenu de la variable $message
					{
						# code...
						echo $message; //Affichage du méssage
					}
				 ?>
				 	
				 </p>
				<form method="post" action="">
					<div class="form-group">
						<input type="text" name="username" class="form-control" placeholder="Votre nom complet">
					</div><br>
					<div class="form-group">
						<input type="mail" name="usermail" class="form-control" placeholder="Votre email">
					</div><br>
					<div class="form-group">
						<input type="tel" name="userwh" class="form-control" placeholder="Votre numéro whatsapp">
					</div><br>
					<input type="submit" name="register" class="btn btn-success" value="Inscription">
				</form>
			</div>
		</div>
	</div>
</body>
</html>